//
//  League.swift
//  Sports App
//
//  Created by Mac on 19/05/2023.
//

import Foundation

class League {
    var id:String?
    var image:String?
    var name:String?
    var sport:String?
    var url:String?
}
